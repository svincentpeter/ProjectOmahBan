<?php

return [
    'name' => 'People'
];
