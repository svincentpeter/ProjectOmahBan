<?php

return [
    'name' => 'Product'
];
